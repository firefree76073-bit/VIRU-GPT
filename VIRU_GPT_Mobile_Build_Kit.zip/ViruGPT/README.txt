VIRU GPT - Android starter project (v1.1)

WHAT WORKS
- Premium black/gold Android WebView interface
- AI chat using OpenAI Responses API (model gpt-4.1-mini)
- AI image generation using OpenAI Images API (model gpt-image-1)
- Voice input through Web Speech API when supported by the device WebView
- API key settings stored locally on the device

WHAT NEEDS AN EXTERNAL PROVIDER
- Video generation is not included. It requires a separate video-generation provider/API and may cost money.
- Chat and image generation require an OpenAI API key, internet access, and API billing/credits. ChatGPT subscriptions do not include API credits.

IMPORTANT SECURITY
This is a personal-use prototype. The API key is stored in WebView localStorage on the device. Do not distribute this build publicly with a personal key. A production app should call a secure backend proxy so API keys are never stored in the APK or client app.

BUILD APK
1. Install Android Studio on a computer.
2. Open the ViruGPT folder as an existing Gradle project.
3. Let Android Studio sync Gradle and install the required Android SDK (compileSdk 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK under app/build/outputs/apk/debug/app-debug.apk.

The project source is provided; this environment does not have Android SDK/Gradle installed, so an installable APK has not been compiled here.
